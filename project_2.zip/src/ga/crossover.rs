use std::collections::HashMap;

use super::problem::{ProblemSolution, SolutionField};
use rand::{
    distributions::{Distribution, Uniform},
    Rng,
};

pub trait ParentCrossoverSystem {
    fn cross_over(&self, parents: &[ProblemSolution]) -> Vec<ProblemSolution>;
}

pub struct DefaultCrossover {
    pub crossover_rate: f64,
}

impl ParentCrossoverSystem for DefaultCrossover {
    fn cross_over(&self, parents: &[ProblemSolution]) -> Vec<ProblemSolution> {
        let mut crossed_overs: Vec<ProblemSolution> = Vec::new();

        let dist = Uniform::from(1..parents[0].0.len() - 1);
        let mut rng = rand::thread_rng();

        for pair in parents.chunks(2) {
            if !rng.gen_bool(self.crossover_rate) {
                crossed_overs.push(pair[0].clone());
                crossed_overs.push(pair[1].clone());
                continue;
            }
            let parent_1 = &pair[0];
            let parent_2 = &pair[1];

            let mut child_1: ProblemSolution =
                ProblemSolution(Vec::with_capacity(parent_1.0.len()));
            let mut child_2: ProblemSolution =
                ProblemSolution(Vec::with_capacity(parent_1.0.len()));

            let crossover_point = dist.sample(&mut rng);
            for i in 0..crossover_point {
                child_1.0.push(parent_1.0[i]);
                child_2.0.push(parent_2.0[i]);
            }

            let child_1_separator_count = child_1.0.iter().filter(|c| c.is_separator()).count();
            let child_2_separator_count = child_2.0.iter().filter(|c| c.is_separator()).count();

            let mut encountered_seps = 0;
            for token in &parent_2.0 {
                match token {
                    SolutionField::Patient(id) => {
                        if !child_1.0.contains(&SolutionField::Patient(*id)) {
                            child_1.0.push(SolutionField::Patient(*id));
                        }
                    }
                    SolutionField::Separator(id) => {
                        if encountered_seps >= child_1_separator_count {
                            child_1.0.push(SolutionField::Separator(*id));
                        }
                        encountered_seps += 1;
                    }
                }
            }
            let mut encountered_seps = 0;
            for token in &parent_1.0 {
                match token {
                    SolutionField::Patient(id) => {
                        if !child_2.0.contains(&SolutionField::Patient(*id)) {
                            //println!("Doesn't contain!!");
                            child_2.0.push(SolutionField::Patient(*id));
                        }
                    }
                    SolutionField::Separator(id) => {
                        if encountered_seps >= child_2_separator_count {
                            child_2.0.push(SolutionField::Separator(*id));
                        }
                        encountered_seps += 1;
                    }
                }
            }
            assert!(
                child_1.0.len() == parent_1.0.len(),
                "c1.len = {}, p1.len = {}",
                child_1.0.len(),
                parent_1.0.len()
            );
            assert!(child_2.0.len() == parent_2.0.len());
            crossed_overs.push(child_1);
            crossed_overs.push(child_2);
        }

        crossed_overs
    }
}

pub struct CycleCrossover {
    pub crossover_rate: f64,
}

impl ParentCrossoverSystem for CycleCrossover {
    fn cross_over(&self, parents: &[ProblemSolution]) -> Vec<ProblemSolution> {
        let mut rng = rand::thread_rng();
        let mut children: Vec<ProblemSolution> = Vec::with_capacity(parents.len());
        for parents in parents.chunks(2) {
            let p_1 = &parents[0];
            let p_2 = &parents[1];
            if !rng.gen_bool(self.crossover_rate) {
                children.push(p_2.clone());
                children.push(p_1.clone());
                continue;
            }
            let start_index = rng.gen_range(0..p_1.0.len());
        }
        todo!()
    }
}

pub struct EdgeCrossover {
    pub crossover_rate: f64,
}

impl ParentCrossoverSystem for EdgeCrossover {
    fn cross_over(&self, parents: &[ProblemSolution]) -> Vec<ProblemSolution> {
        let mut rng = rand::thread_rng();
        let mut children: Vec<ProblemSolution> = Vec::with_capacity(parents.len());
        for parents in parents.chunks(2) {
            let p_1 = &parents[0];
            let p_2 = &parents[1];
            if !rng.gen_bool(self.crossover_rate) {
                children.push(p_2.clone());
                children.push(p_1.clone());
                continue;
            }
            let tokens = p_1.0.len();
            let mut edge_table: HashMap<SolutionField, Vec<SolutionField>> = HashMap::new();
            for i in 0..tokens {
                let t_0 = p_1.0[i];
                let edge_left;
                let edge_right;
                if i == 0 {
                    edge_left = p_1.0[tokens-1]
                } else {
                    edge_left = p_1.0[i - 1];
                }
                if i == tokens - 1 {
                    edge_right = p_1.0[0];
                } else {
                    edge_right = p_1.0[i + 1];
                }
                edge_table.get_mut(&t_0).unwrap().push(edge_left);
                edge_table.get_mut(&t_0).unwrap().push(edge_right);

                let t_0 = p_2.0[i];
                let edge_left;
                let edge_right;
                if i == 0 {
                    edge_left = p_2.0[tokens-1]
                } else {
                    edge_left = p_2.0[i - 1];
                }
                if i == tokens - 1 {
                    edge_right = p_2.0[0];
                } else {
                    edge_right = p_2.0[i + 1];
                }
                edge_table.get_mut(&t_0).unwrap().push(edge_left);
                edge_table.get_mut(&t_0).unwrap().push(edge_right);
            }

            for parent in [p_1, p_2] {
                let mut built_list: Vec<SolutionField> = Vec::new();
                let mut current_element = parent.0[rng.gen_range(0..tokens)];
                let mut done = false;
                while !done {
                    built_list.push(current_element.clone());
                    // remove references
                    for (_, val) in edge_table.iter_mut() {
                        val.retain(|&x| x != current_element);
                    }
                    let candidates = edge_table.get(&current_element).unwrap();
                    
                    let mut counts = vec![1; 4];
                    if candidates[0] == candidates[1] || candidates[0] == candidates[2] || candidates[0] == candidates[3] {
                        current_element = candidates[0];
                    } else if candidates[1] == candidates[2] || candidates[1] == candidates[3] {
                        current_element = candidates[1];
                    } else if candidates[2] == candidates[3] {
                        current_element = candidates[2];
                    }
                }

            }
        }

        todo!()
    }
}
